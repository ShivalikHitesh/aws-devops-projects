
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $firstname = $_POST['firstname'] ?? '';
    $email = $_POST['email'] ?? '';

    $servername = "intel-db.c0b66qs22zfi.us-east-1.rds.amazonaws.com";
    $username = "admin";
    $password = "intel123";
    $db = "intel";

    $conn = new mysqli($servername, $username, $password, $db);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if (!empty($firstname) && !empty($email)) {

        $sql = "INSERT INTO data (firstname, email)
                VALUES ('$firstname', '$email')";

        if ($conn->query($sql) === TRUE) {
            $message = "New record created successfully";
        } else {
            $message = "Database Error: " . $conn->error;
        }

    } else {
        $message = "Please enter both Name and Email";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Registration</title>

    <link rel="stylesheet"
          href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>

<body background="images/2.png"
      style="background-repeat:no-repeat;background-size:100% 100%;">

<br><br><br><br>

<div class="container">
    <div class="jumbotron">

        <h3>User Information Form</h3>

        <?php
        if (!empty($message)) {
            echo "<div class='alert alert-info'>$message</div>";
        }
        ?>

        <form method="post">

            <div class="form-group">
                <label>Name:</label>
                <input type="text"
                       class="form-control"
                       name="firstname"
                       required>
            </div>

            <div class="form-group">
                <label>Email:</label>
                <input type="email"
                       class="form-control"
                       name="email"
                       required>
            </div>

            <button type="submit"
                    class="btn btn-success">
                Submit
            </button>

        </form>

    </div>
</div>

</body>
</html>

